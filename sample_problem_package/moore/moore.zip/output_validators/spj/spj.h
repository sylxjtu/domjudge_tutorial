#include <string>

bool checkInt(const std::string& s, std::string& errorMessage);
bool spj(const std::string& s, int n, std::string& errorMessage);