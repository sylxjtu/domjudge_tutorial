#include <bits/stdc++.h>
using namespace std;
int main(){
    for(int i = 0; i < 100001; i++) {
        cout << "1";
    }
    cout << endl;
}