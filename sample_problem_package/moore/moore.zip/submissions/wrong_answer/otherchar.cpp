#include <bits/stdc++.h>
using namespace std;
int main(){
    long long n; cin >> n;
    cout << (1ll << n) << endl;
}